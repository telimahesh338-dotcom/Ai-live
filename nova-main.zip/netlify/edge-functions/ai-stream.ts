// @ts-nocheck
const MODEL_ID = "google/gemini-2.0-flash-exp:free"; 

const SYSTEM_MESSAGES = {
  "ar-LB": "أنت مساعد شخصي ذكي اسمه نوفا. أجب بشكل مباشر.",
  "fr-FR": "Vous êtes Nova, un assistant intelligent. Répondez directement.",
  "en-US": "You are Nova, an intelligent assistant. Answer directly."
};

export default async (request) => {
  if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const body = await request.json();
  const apiKey = Deno.env.get("OPENROUTER_API_KEY");

  const messages = [
    { role: "system", content: SYSTEM_MESSAGES[body.language] || SYSTEM_MESSAGES["en-US"] },
    ...(body.history || []).map(m => ({ 
        role: m.role === "assistant" ? "assistant" : "user", 
        content: m.text 
    })),
    { role: "user", content: body.query }
  ];

  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "https://n0v0.netlify.app/",
      "X-Title": "Nova AI"
    },
    body: JSON.stringify({
      model: MODEL_ID,
      messages,
      stream: true
    })
  });

  const reader = response.body.getReader();
  const decoder = new TextDecoder();

  const stream = new ReadableStream({
    async start(controller) {
      const encoder = new TextEncoder();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split("\n");

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const dataStr = line.slice(6).trim();
            if (dataStr === "[DONE]") continue;

            try {
              const json = JSON.parse(dataStr);
              const text = json.choices[0]?.delta?.content || "";
              if (text) {
                controller.enqueue(encoder.encode(`data: ${JSON.stringify({ text })}\n\n`));
              }
            } catch (e) {}
          }
        }
      }
      controller.enqueue(encoder.encode("data: [DONE]\n\n"));
      controller.close();
    }
  });

  return new Response(stream, { headers: { "Content-Type": "text/event-stream" } });
};

export const config = { path: "/api/ai-stream" };