import type { Handler, HandlerEvent } from "@netlify/functions";

// Free Model ID
const MODEL_ID = "google/gemini-2.0-flash-exp:free"; 

type SupportedLanguage = "en-US" | "ar-LB" | "fr-FR";

const SYSTEM_MESSAGES: Record<SupportedLanguage, string> = {
  "ar-LB": "أنت مساعد شخصي ذكي اسمه نوفا. أجب بشكل مباشر وقصير.",
  "fr-FR": "Vous êtes Nova, un assistant intelligent. Répondez directement et brièvement.",
  "en-US": "You are Nova, an intelligent assistant. Answer directly, concisely and accurately.",
};

const handler: Handler = async (event: HandlerEvent) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method Not Allowed" };

  try {
    const requestBody = JSON.parse(event.body || "{}");
    const apiKey = process.env.OPENROUTER_API_KEY;

    const messages = [
      { role: "system", content: SYSTEM_MESSAGES[requestBody.language as SupportedLanguage] || SYSTEM_MESSAGES["en-US"] },
      ...(requestBody.history || []).map((m: any) => ({ 
        role: m.role === "assistant" ? "assistant" : "user", 
        content: m.text 
      })),
      { role: "user", content: requestBody.query }
    ];

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://n0v0.netlify.app/",
        "X-Title": "Nova AI"
      },
      body: JSON.stringify({
        model: MODEL_ID,
        messages: messages,
        temperature: 0.7,
        max_tokens: 1000
      })
    });

    const data = await response.json();
    const text = data.choices?.[0]?.message?.content || "Sorry, I couldn't process that.";

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ responseText: text.trim(), language: requestBody.language }),
    };
  } catch (error) {
    return { statusCode: 502, body: JSON.stringify({ error: true, responseText: "Connection error." }) };
  }
};

export { handler };